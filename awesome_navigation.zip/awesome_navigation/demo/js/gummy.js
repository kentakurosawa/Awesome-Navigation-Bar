$(function(){
    var nav    = $("nav#gummy");
    var navTop = nav.offset().top;
    $(window).scroll(function () {
        if($(window).scrollTop() >= navTop) {
            nav.addClass("gummy");	
        } else {
            nav.removeClass("gummy");
        }
    });
});

